<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Multilingual Greetings</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <img src="images/wikipedia.png" alt="Wikipedia">
        <div class="credits" id="credits">Juan MORALES</div>
        <br>

    <?php  

        if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["textWrittenByUser"])) {
            echo "<div id='greeting' class='greeting'>" . $_POST["textWrittenByUser"] . "</div>";    
        }

    ?>

        <form action="" method="post">
            <input type="text" name="textWrittenByUser" id="textWrittenByUser">
            <input type="submit" id="changeGreeting" class="change-btn">
        </form>
        
    </div>

    <script src="js/script.js"></script>

</body>
</html>
